package pub.cdl.cameraalbumtest.bean;

/**
 * 2 * @Author: cdlfg
 * 3 * @Date: 2019/4/30 0:40
 * 4
 */
public class TrResult {
    private String src;
    private String dst;

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getDst() {
        return dst;
    }

    public void setDst(String dst) {
        this.dst = dst;
    }
}
