package pub.cdl.cameraalbumtest.bean;

/**
 * 2 * @Author: cdlfg
 * 3 * @Date: 2019/5/17 23:17
 * 4
 */
public class DicStatus {
    private String name;
    private String isLoaded;
    private String isOn;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIsLoaded() {
        return isLoaded;
    }

    public void setIsLoaded(String isLoaded) {
        this.isLoaded = isLoaded;
    }

    public String getIsOn() {
        return isOn;
    }

    public void setIsOn(String isOn) {
        this.isOn = isOn;
    }
}
