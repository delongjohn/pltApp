package pub.cdl.cameraalbumtest.bean;

/**
 * 2 * @Author: cdlfg
 * 3 * @Date: 2019/5/2 14:45
 * 4
 */
public class Text {
    private String time;
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
