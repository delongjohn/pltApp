package pub.cdl.cameraalbumtest.value;

import android.os.Environment;

/**
 * 2 * @Author: cdlfg
 * 3 * @Date: 2019/4/22 17:54
 * 4
 */
public class Provide {
    public static final String TAG_MAIN = "MainActivity";
    public static final String TESS_DATA = Environment.getExternalStorageDirectory().toString() + "/TessData/";
    public static final String TESS_DATA_LOCAL = "tessData";
}
