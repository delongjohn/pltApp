package pub.cdl.cameraalbumtest.util;

import com.baidu.tts.client.SpeechSynthesizerListener;
import com.baidu.tts.client.TtsMode;
import pub.cdl.cameraalbumtest.listener.UiMessageListener;

/**
 * 2 * @Author: cdlfg
 * 3 * @Date: 2019/4/26 22:54
 * 4
 */
public class ConfigUtil {
}
