package pub.cdl.cameraalbumtest;

/**
 * Created by fujiayi on 2017/9/13.
 */

public interface MainHandlerConstant {
    static final int PRINT = 0;
    static final int UI_CHANGE_INPUT_TEXT_SELECTION = 1;
    static final int UI_CHANGE_SYNTHES_TEXT_SELECTION = 2;

    static final int INIT_SUCCESS = 2;

    int TR_OK = 3;
    int TR_FAILD = 4;
}
